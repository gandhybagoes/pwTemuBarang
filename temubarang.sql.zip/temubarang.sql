-- phpMyAdmin SQL Dump
-- version 4.4.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jan 24, 2017 at 05:36 AM
-- Server version: 5.5.42
-- PHP Version: 7.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `temubarang`
--

-- --------------------------------------------------------

--
-- Table structure for table `ambil`
--

CREATE TABLE `ambil` (
  `id_pengambilan` varchar(10) NOT NULL,
  `id_barang` varchar(10) NOT NULL,
  `nama_pengambilan` varchar(40) NOT NULL,
  `notelp_pengambilan` varchar(13) NOT NULL,
  `kelas_pengambilan` varchar(10) NOT NULL,
  `tanggal pengambilan` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `barang`
--

CREATE TABLE `barang` (
  `id_barang` varchar(20) NOT NULL,
  `nama_barang` varchar(30) NOT NULL,
  `ket_barang` text NOT NULL,
  `jenis_barang` varchar(10) NOT NULL,
  `lokasi_barang` text NOT NULL,
  `foto_barang` text NOT NULL,
  `id_status` varchar(11) NOT NULL,
  `confirmA` int(2) NOT NULL,
  `confirmB` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `barang`
--

INSERT INTO `barang` (`id_barang`, `nama_barang`, `ket_barang`, `jenis_barang`, `lokasi_barang`, `foto_barang`, `id_status`, `confirmA`, `confirmB`) VALUES
('crg111', 'charger', 'charger asus', 'charger', 'XIIR1', 'kepo', 'st1', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `chat`
--

CREATE TABLE `chat` (
  `id_chat` varchar(10) NOT NULL,
  `isi_chat` text NOT NULL,
  `tanggal_chat` date NOT NULL,
  `status_chat` int(11) NOT NULL,
  `id_chatlist` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `chatlist`
--

CREATE TABLE `chatlist` (
  `id_chatlist` varchar(10) NOT NULL,
  `name_chatlist` text NOT NULL,
  `date_chatlist` date NOT NULL,
  `priority_chatlist` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `id_log` varchar(10) NOT NULL,
  `aksi_log` varchar(15) NOT NULL,
  `detail_log` text NOT NULL,
  `tanggal_log` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id_user` varchar(10) NOT NULL,
  `nama_user` varchar(40) NOT NULL,
  `password_user` varchar(30) NOT NULL,
  `type_user` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id_user`, `nama_user`, `password_user`, `type_user`) VALUES
('1', 'aa', 'aa', 1);

-- --------------------------------------------------------

--
-- Table structure for table `online`
--

CREATE TABLE `online` (
  `id_online` varchar(10) NOT NULL,
  `session_online` text NOT NULL,
  `status_online` varchar(20) NOT NULL,
  `id_user` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `id_profile` varchar(10) NOT NULL,
  `nama_user` varchar(40) NOT NULL,
  `username_user` varchar(20) NOT NULL,
  `notelp_user` varchar(13) NOT NULL,
  `foto_user` text NOT NULL,
  `kelas_user` varchar(10) NOT NULL,
  `noabsen_user` varchar(3) NOT NULL,
  `id_user` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`id_profile`, `nama_user`, `username_user`, `notelp_user`, `foto_user`, `kelas_user`, `noabsen_user`, `id_user`) VALUES
('1', 'AA binto AA', 'aa', '088828288', 'hhhh', 'XIIRPL1', '25', '1');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id_status` varchar(11) NOT NULL,
  `nama_status` varchar(11) NOT NULL,
  `code_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id_status`, `nama_status`, `code_status`) VALUES
('st1', 'available', '<td><span class="label label-info label-mini">Available</span></td>'),
('st2', 'pending', '<td><span class="label label-warning label-mini">Pending</span></td>'),
('st3', 'Diambil', '<td><span class="label label-danger label-mini">Diambil</span></td>'),
('st4', 'noclick', '<td>\r\n                                      <button class="btn btn-success btn-xs"><i class="fa fa-check"></i></button>\r\n                                      <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>\r\n                                      <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>\r\n</td>'),
('st5', 'oneclick', '<td>\r\n                                      <button class="btn btn-success btn-xs"><i class="fa fa-check" disabled></i></button>\r\n                                      <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>\r\n                                      <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>\r\n</td>'),
('st6', 'twoclick', '<td>\r\n                                      <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>\r\n                                      <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>\r\n</td>'),
('cs1', 'noaction', '<td>\r\n                                      <button class="btn btn-primary btn-xs"><i class="fa fa-pencil"></i></button>\r\n                                      <button class="btn btn-danger btn-xs"><i class="fa fa-trash-o "></i></button>\r\n</td>');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ambil`
--
ALTER TABLE `ambil`
  ADD PRIMARY KEY (`id_pengambilan`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indexes for table `chat`
--
ALTER TABLE `chat`
  ADD PRIMARY KEY (`id_chat`);

--
-- Indexes for table `chatlist`
--
ALTER TABLE `chatlist`
  ADD PRIMARY KEY (`id_chatlist`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `online`
--
ALTER TABLE `online`
  ADD PRIMARY KEY (`id_online`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`id_profile`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
