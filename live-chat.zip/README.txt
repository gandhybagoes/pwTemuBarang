A Pen created at CodePen.io. You can find this one at http://codepen.io/marcobiedermann/pen/rohwn.

 View it at <a href="http://drbl.in/iesc">dribbble</a> or <a href="http://bit.ly/13iaBdi">Behance</a>